from PyQt5 import QtCore, QtGui, QtWidgets
import pyowm
import sys
import json
from pyowm.utils.config import get_default_config
from PyQt5.QtWidgets import QInputDialog
exec(open("./config.py").read())
config_dict = get_default_config()
config_dict['language'] = 'ru'  
places = (place)
owmsk = (owmsk)
class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(780, 298)
        Form.setMinimumSize(QtCore.QSize(780, 298))
        Form.setMaximumSize(QtCore.QSize(780, 298))
        self.pushButton = QtWidgets.QPushButton(Form)
        self.pushButton.setGeometry(QtCore.QRect(10, 10, 161, 71))
        self.pushButton.setCheckable(False)
        self.pushButton.setChecked(False)
        self.pushButton.setObjectName("pushButton")
        self.pushButton.clicked.connect(self.temp)
        self.pushButton_2 = QtWidgets.QPushButton(Form)
        self.pushButton_2.setGeometry(QtCore.QRect(610, 10, 167, 71))
        self.pushButton_2.setCheckable(False)
        self.pushButton_2.setChecked(False)
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_2.clicked.connect(self.info)
        self.pushButton_3 = QtWidgets.QPushButton(Form)
        self.pushButton_3.setGeometry(QtCore.QRect(290, 10, 161, 71))
        self.pushButton_3.setCheckable(False)
        self.pushButton_3.setChecked(False)
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_3.clicked.connect(self.saves)
        self.frame = QtWidgets.QFrame(Form)
        self.frame.setGeometry(QtCore.QRect(0, 90, 781, 211))
        self.frame.setMinimumSize(QtCore.QSize(781, 211))
        self.frame.setMaximumSize(QtCore.QSize(781, 211))
        self.frame.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.label = QtWidgets.QLabel(self.frame)
        self.label.setGeometry(QtCore.QRect(20, 20, 731, 161))
        self.label.setObjectName("label")    

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)
    def temp(self, Form): # Узнаёт погоду и сохраняет инфу
        text1, ok = QtWidgets.QInputDialog.getText(None, 'Api', 'Введите api с сайта https://home.openweathermap.org/users/sign_up')
        owms = text1
        owm = pyowm.OWM(owms)
        mgr = owm.weather_manager()
        if ok:
            text, ok = QtWidgets.QInputDialog.getText(None, 'Город', 'Ведите название города:')
        place = text
        observation = mgr.weather_at_place(place)
        w = observation.weather
        temp = w.temperature('celsius')["temp"]
        winds = str(w.wind())
        if ok:
            self.label.setText(str("Погода в городе " + place + ": " + winds + ", " + str(temp) + "?C" + "Чтобы заработало узнавание по последним данным перезапустите приложение"))
        f = open('config.py', 'wt')
        f.write(str("owmsk = '" +owms + "'" "\n" + "place = '" + place + "'"))
        f.close()
    def saves(self, Form): # Быстрое узнавание инфы
        owm = pyowm.OWM(owmsk)
        mgr = owm.weather_manager()
        observation = mgr.weather_at_place(places)
        w = observation.weather
        temp = w.temperature('celsius')["temp"]
        winds = str(w.wind())
        self.label.setText(str("Погода в городе " + place + ": ""Ветер" + winds + ", " + str(temp) + "°C" ))
        
    def info(self, Form): # about
        info = str("Здесь пока ничего интересного нету")
        self.label.setText(info)


    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Погода"))
        self.pushButton.setText(_translate("Form", "Узнать погоду"))
        self.pushButton_2.setText(_translate("Form", "Информация о программе"))
        self.pushButton_3.setText(_translate("Form",  "Погода"))
        self.label.setText(_translate("Form", "Чтобы узнать api зарегестрируйтесь на этом сайте https://home.openweathermap.org/users/sign_up"))
    def save (self, Form):
        owms = api(self.api)
        f = open('config.py', 'wt')
        f.write("owms  = "+ owms)
        f.close()
        
        


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Form = QtWidgets.QWidget()
    ui = Ui_Form()
    ui.setupUi(Form)
    Form.show()
    sys.exit(app.exec_())
 


