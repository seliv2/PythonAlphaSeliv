owmsk = ''
place = ''